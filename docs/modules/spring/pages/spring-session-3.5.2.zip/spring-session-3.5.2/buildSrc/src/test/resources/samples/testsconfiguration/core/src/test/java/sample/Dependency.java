package sample;

public class Dependency {}