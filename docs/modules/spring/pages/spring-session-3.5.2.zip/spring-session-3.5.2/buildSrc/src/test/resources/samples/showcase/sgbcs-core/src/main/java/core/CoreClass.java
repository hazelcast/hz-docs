package core;

/**
 *
 * @author Rob Winch
 *
 */
public class CoreClass {

	public void run() {

	}
}
